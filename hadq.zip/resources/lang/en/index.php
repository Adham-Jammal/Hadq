<?php

return [

    'main' => 'Home page',
    'contactUs' => 'Contact Us',
    'lang' => 'العربية',
    'vision' => '#Our Vision',
    'ourMessage' => '#Our Message',
    'ourGoals' => '#Our Goals',
    'ourServices' => 'Our Services',
    'partners' => 'success partners',
    'question' => 'Still have a questions?',
    'fill' => 'Fill out the form',
    'fullname' => 'Full Name',
    'email' => 'Email',
    'phonenumber' => 'Phone number',
    'service' => 'Service',
    'message' => 'Your Message',
    'send' => 'send',
    'stillContact' => 'Stay In Touch',
    'ready' => 'We are ready to any suggestions or just to chat',
    'headquarters' => 'Our headquarters and contact information:',
    'aboutCompany' => 'A Saudi company that works diligently to improve the quality of life by providing unparalleled solutions.',
    'contactInfo' => 'Contact Info',
    'address' => 'TDIX Address',
    'group' => 'One of the companies of the Oj Group Ltd.',




];
