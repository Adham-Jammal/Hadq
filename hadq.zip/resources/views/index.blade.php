@extends('app')

@php
$lang = ucfirst(LaravelLocalization::getCurrentLocale());
$index = 1;
@endphp


{{-- Success message --}}
@section('main')
@if (session()->has('message'))
<script src="{{ asset('js/formerror.js') }}"></script>
@endif

{{-- Error message --}}

@if ($errors->any())
<script src="{{ asset('js/formerror.js') }}"></script>
@endif



<section class="main-section">
    <div class="container">
        {{-- header start --}}
        <header>
            <div class="header-logo">
                <img   src="{{ Voyager::image($data->logo) }}" alt="logo">
            </div>
            <div class="header-list">
                <ul>
                    <li><a href="#hero">{{ __('index.main') }}</a></li>
                    <li><a href="#gallery">معرض الأعمال</a></li>
                    {{-- <li><a href="/{{ LaravelLocalization::getCurrentLocale() == 'ar' ? 'en' : 'ar' }}">{{
                            __('index.lang') }}</a>
                    </li> --}}
                    <li>
                        <a href="#Success">عـمـلاءنا</a>
                    </li>
                    <li>
                        <a href="#contact_us"> طلب خدمة</a>
                    </li>


                </ul>
            </div>
        </header>

        
        {{-- end of header --}}
        {{-- hero start --}}
        <div class="hero" id="hero">
            <div class="row" >
                <div class="col-md-6 hero-text-content" data-aos="fade-up" data-aos-duration="1000">
                    <h2 hidden style="font-size: 55px !important">
                        {{ $data['main_word_header_' . $lang] }}

                    </h2>
                    <br>
                    <h4 style="font-size: 40px  !important" class="title-header" id="header">‎</h4>
                    <p style="font-size: 20px">
                                            {{ $data['royaa_desc_' . $lang] }}
                    </p>

                    <div class="circule-image">
                        {{-- <img src="{{ asset('img/circule-word.png') }}" alt=""> --}}
                    </div>
                </div>
                <div  class="col-6"  id="particles-js" data-aos="fade-down"
                    data-aos-duration="1000">

             
                </div>
            </div>
        </div>
        {{-- end of hero --}}

        {{-- vision start --}}
        {{-- <div class="vision" id="vision">
            <div class="row align-items-center">

                <div class="col-md-6 vision-image-content" data-aos="zoom-in" data-aos-duration="1000">
                    <img src="{{ Voyager::image($data->image_royaa_message) }}" alt="">
                </div>

                <div class="col-md-6 vision-text-content" data-aos="fade-right" data-aos-duration="1000">
                    <h3>{{ __('index.vision') }}</h3>
                    <p>
                        {{ $data['royaa_desc_' . $lang] }}
                    </p>
                </div>

            </div>
        </div> --}}
        {{-- end of vision --}}
    </div>
</section>

<div id="gallery"></div>

{{-- Success Partners
--}} <section id="Success" class="our-message">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">عـمـلاءنا</h1>

            </div>


            <div class="col-12  justify-content-center">
                <div class="center-block" data-aos="zoom-in" data-aos-duration="1000">
                </div>



                <div class="center-block owl-carousel owl-theme" id="owl-carousel2" data-aos="fade-down"
                    data-aos-duration="1000">

                    @foreach ( json_decode($data->success_partners, true) as $image)
                    <div class="img-p">
                        <img src="{{ Voyager::image($image) }}" alt="">
                    </div>
                    @endforeach

                </div>

            </div>
        </div>
    </div>
</section>


{{-- end of Success Partners--}}


    {{-- contact section --}}
    <section class="contact-us" id="contact_us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6 form-content">
                    <h3>لـطـلـب هويـتـك</h3>
                    <p>{{ __('index.fill') }}</p>
                    <form action="request" method="POST">
                        @csrf

                        <div class="row">

                        <div class="input-field col-6">
                            <label for="name">{{ __('index.fullname') }}</label>
                            <input required type="text" name="name" id="full_name">
                        </div>
                        <div class="input-field col-6">
                            <label for="email"> {{ __('index.email') }}</label>
                            <input  type="email" name="email" id="email">
                        </div>
                        <div class="input-field col-6">
                            <label for="phone">{{ __('index.phonenumber') }}</label>
                            <input required type="number" name="phone" id="phone_number">
                        </div>
                        <div class="input-field col-6">
                            <label for="name"> موقع العمل </label>
                            <input required type="text" name="location" id="full_name">
                        </div>
                        <div class="input-field col-6">
                            <label for="service">نبذة عن مشروعك</label>
                            <select required id="service_id" name="nbza">
                                <option>-يرجى الاختيار-</option>
                                {{-- @foreach ($services as $service)
                                    <option value="{{ $service['title_ar'] }}">{{ $service['title_' . $lang] }}
                                    </option>
                                @endforeach --}}
                                <option value="مشروع جديد"> مشروع جديد</option>
                                <option value=" تجديد هوية " > تجديد هوية </option>

                            </select>
                        </div>

                        <div class="input-field col-6">
                            <label for="service"> احتياجك</label>
                            <select required id="service_id" name="service">
                                <option>-يرجى الاختيار-</option>
                                {{-- @foreach ($services as $service)
                                    <option value="{{ $service['title_ar'] }}">{{ $service['title_' . $lang] }}
                                    </option>
                                @endforeach --}}
                                <option value="هوية كاملة"> هوية كاملة</option>
                                <option value="شعار ورسمة "> شعار ورسمة </option>
                                <option value="شعار فقط"> شعار فقط</option>

                            </select>
                        </div>

                     

                        <div class="input-field col-12">
                            <label for="message">ملاحظاتك</label>
                            <textarea required name="message" id="message" cols="30" rows="7"></textarea>
                        </div>
                        <div class="input-field col-6">
                            <input  type="submit" value="طلب الخدمة">
                        </div>

                </div>

                    </form>

                </div>
                <div class="col-md-6 contact-image-content" data-aos="zoom-out" data-aos-duration="1000">
                    <img src="{{ Voyager::image($data->form_image) }}" alt="">
                </div>
            </div>
        </div>
    </section>
    {{-- end of contact --}}


<style>
    .title {
        font-size: 36px;
        text-align: center;
        color: #fff;
        padding: 15px;
        margin-bottom: 35px;
    }

    .main-section header .header-logo img {
        width: 180px;
        border-radiuss:  59px;
    }

    .img-p img {
        width: 175px !important;
        height: 175px !important;
        border-radiuss:  75px;
    }

    .img-p {
        padding: 25px;

    }

    .cen {
        text-align: center;
    }

    .section {
        color: #fff;
        width: 100%;
        position: relative;
        min-height: 100vh;
        padding-bottom: 80px;
        border-bottom: 3px solid rgba(250, 250, 250, 0.25);
    }

    /* Buttons */

    button {
        /* display271: inline-block; */
        padding: 10px 20px;
        margin: 5px 5px;
        background-color: #fff;
        color: #6f7868;
        font-size: 12px;
        font-weight: 800;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        transition: all 0.5s;
        border: none;
        outline: none;
        cursor: pointer;
        border-radiuss:  5px;
        box-shadow: rgba(0, 0, 0, 0.2) 0px 12px 28px 0px, rgba(0, 0, 0, 0.1) 0px 2px 4px 0px, rgba(255, 255, 255, 0.05) 0px 0px 0px 1px inset;
    }

    button:hover {
        outline: none;
        background-color: #0e0e0e !important;
        color: #fff;
    }

    button.active {
        outline: none;
        background-color: #000;
        color: #fff;
    }


    /*    isotope       */
    .section-heading {
        text-align: center;
        padding: 80px 45px 50px 45px;
    }

    .isotope-wrapper {
        /* display271: flex; */
        flex-direction: column;
        position: relative;
        width: 100%;
        margin: auto;
    }

    .isotope-toolbar span {
        text-transform: capitalize;
        /* display271: inline-block; */
        /*   margin-right: 15px;
  padding-bottom: 3px; */
        font-size: 15px;
        font-weight: 700;
        border-bottom: 2px solid transparent;
        transform: ease-in-out 0.5s;
        cursor: pointer;
        flex: 1;
    }

    .isotope-box {
        position: relative;
        width: 100%;
        flex: 1;
    }

    .isotope-toolbar {
        text-align: right;
        margin: 10px;
    }

    .isotope-item {
        box-shadow: rgba(0, 0, 0, 0.2) 0px 12px 28px 0px, rgba(0, 0, 0, 0.1) 0px 2px 4px 0px, rgba(255, 255, 255, 0.05) 0px 0px 0px 1px inset;
        position: relative;
        width: 48%;
        margin: 1%;
        /* border-bottom: 2px solid rgba(250, 250, 250, 0.1); */
        /* padding-bottom: 30px; */
        margin-bottom: 30px;
    }

    .isotope-item img {
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radiuss:  5px;
    }

    figure {
        overflow: hidden;
        text-align: center;
        -webkit-perspective: 50em;
        perspective: 50em;
    }

    figure * {
        -webkit-box-sizing: padding-box;
        box-sizing: padding-box;
        -webkit-transition: all 0.2s ease-out;
        transition: all 0.2s ease-out;
    }

    figure figcaption {
        top: 50%;
        left: 20px;
        right: 20px;
        position: absolute;
        opacity: 0;
        z-index: 1;
    }

    figure h4 {
        margin-top: 15px;
        margin-bottom: 5px;
        color: #232323;
    }

    figure span {
        font-size: 14px;
        font-style: italic;
        /* display271: block; */
        color: #7a7a7a;
    }

    figure svg {
        position: relative !important;
        font-size: 18px;
        /* background-color: #6f7868; */
        width: 60px;
        height: 70px;
        padding: 5px;
        /* display271: inline-block; */
        text-align: center;
        line-height: 40px;
        border-radiuss:  5px;
        color: #fff;
        fill: red;
    }

    figure:after {
        /* background-color: #ffffff; */
        position: absolute;
        content: "";
        /* display271: block; */
        top: 0px;
        left: 0px;
        right: 0px;
        bottom: 0px;
        -webkit-transition: all 0.4s ease-in-out;
        transition: all 0.4s ease-in-out;
        -webkit-transform: rotateX(-90deg);
        transform: rotateX(-90deg);
        -webkit-transform-origin: 50% 50%;
        -ms-transform-origin: 50% 50%;
        transform-origin: 50% 50%;
        opacity: 0;
    }

    figure a {
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        z-index: 1;
    }

    figure:hover figcaption,
    figure.hover figcaption {
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
        opacity: 1;
        -webkit-transition-delay: 0.2s;
        transition-delay: 0.2s;
    }

    figure:hover:after,
    figure.hover:after {
        -webkit-transform: rotateX(0);
        transform: rotateX(0);
        opacity: 0.9;
    }

    .our-message{
    margin-top: 475px;

        }
    figure:after {}

    @media (max-width:768px) {
        .isotope-item {
            width: 96%;

        }
    }

    body {
        overflow: hidden;
        background: #fff;

    }

    .title-header {
        font-size: 26px !important;
    }

    .sand{
        /* font-weight: 900; */
        color: #ffffff;
    }
    
    .contact{
    background: #fff;
    width: 25px !important;
    height: 25px !important;
    margin: 5px;
    text-align: center;
    padding-top: 5px;
    height: 15px;
    border-radius:  40px;
    margin: 10px;
}    
.contact i {
    font-size: 16px;
    color: #000;
}

a:hover{
    color: #b5c3a9 !important;
    font-weight: bolder;
}
</style>


<script>
    
var i = 0;
var txt =" {{ $data['title_header_' . $lang] }}";
var speed = 90;

function typeWriter() {
  if (i < txt.length) {
    document.getElementById("header").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}



</script>


@stop