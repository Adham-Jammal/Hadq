<!DOCTYPE html>
<html>

<head>
    <link href='https://fonts.googleapis.com/css?family=Cairo' rel='stylesheet'>
    <style>
        * {
            font-family: 'Cairo';
            font-size: 22px;
        }
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <style>
        * {
            font-family: 'Cairo';
            font-size: 22px;
        }
    </style>
    <link href='https://fonts.googleapis.com/css?family=Cairo' rel='stylesheet'>

    <center>
        <img src="https://i.ibb.co/rFsxzCW/440caf16327393-5c96db9c51f7d-removebg-preview.png" alt="حدق">
        <br>
        <h3>طلب خدمة من {{$name}}</h3>
    </center>



    <table class="table table-bordered">
        <thead>

            <tr>
                <th scope="col">رقم الهاتف</th>
                <th></th>
                <th scope="col">الإيميل </th>
                <th></th>
                <th scope="col">نبذة عن العمل</th>


            </tr>
        </thead>
        <tbody>


            <tr>
                <td>{{$phone}}</td>
                <th></th>
                <td>{{$email}}</td>
                <th></th>
                <td>{{$nbza}}</td>

            </tr>

        </tbody>

    </table>

    <table class="table table-bordered">
        <thead>

            <tr>

                <th scope="col"> الخدمة </th>
                <th></th>
                <th scope="col">الملاحظات</th>

            </tr>
        </thead>
        <tbody>


            <tr>

                <td>{{$service}}</td>
                <th></th>
                <td>{{$msg}}</td>
            </tr>

        </tbody>

    </table>
</body>

</html>