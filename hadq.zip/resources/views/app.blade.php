<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hadq | حَـــــدق
    </title>

    <meta name="description" content="Branding, Graphic designer.    ">
    <meta property="og:description" content="Branding, Graphic designer.    ">

    <meta name="keywords" content="حدق, Branding, Graphic designer, designer,  حَدق , Graphic , تصميم , هوية , تجارية" />
    <meta property="og:type" content="website">
    <meta property="og:title" content="Hadq | حَـــــدق">
  

    <link  href="https://i.ibb.co/vdJbM6C/440caf16327393-5c96db9c51f7d-removebg-preview-1.png" rel="icon">
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-v4-grid-only@1.0.0/dist/bootstrap-grid.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('css/style.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.css">
    <link rel="stylesheet" href="{{ asset('css/footer.css')}}">
    <link rel="stylesheet" href="{{ asset('css/'.LaravelLocalization::getCurrentLocale().'-style.css')}}">

</head>
<body>
    <div id="preloader"></div>
    {{-- <button id="chat_with_us"><i class="fas fa-comment-alt"></i></button> --}}
    {{-- <a class="to_up" href="#" onclick="$(window).scrollTop(0);"><i class="fa fa-arrow-up"></i></a> --}}
    <a class="to_up" id="button"></a>

    @include('layouts.header')

    @yield('main')

    @include('layouts.footer')
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
        
        <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
        <script src="https://threejs.org/examples/js/libs/stats.min.js"></script>
        
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>

<script src="{{ asset('js/main-'.LaravelLocalization::getCurrentLocale().'.js')}}"></script>

{{-- Success message --}}
@if(session()->has('message'))
<script src="{{ asset('js/success-message-'.LaravelLocalization::getCurrentLocale().'.js')}}"></script>
<script src="{{ asset('js/main-'.LaravelLocalization::getCurrentLocale().'.js')}}"></script>

@endif

{{--Error message --}}

@if ($errors->any())
        <script src="{{ asset('js/error-messag-'.LaravelLocalization::getCurrentLocale().'.js')}}"></script>
@endif
<script src="https://cdn.jsdelivr.net/npm/lozad/dist/lozad.min.js"></script>

</body>
</html>

