{{-- footer --}}

<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 logo">
                <img src="https://i.ibb.co/B3MrbnX/Logo-03.png"  alt="logo">

            </div>
            <div class="col-md-5 social-media-links">
                <p>
{{$data->footer}}                <div class="social-media">
    @if (isset($data->behance ))
        
                    <a target="_blank" href="{{$data->behance}}">
                    <i class="fab fa-behance"></i>

                    </a>
        @endif
        @if (isset($data->twitter ))

                    <a  target="_blank" href="{{$data->twitter}} ">
                    <i class="fab fa-twitter" aria-hidden="true"></i>

                    </a>
@endif
@if (isset($data->mail_1 ))

<a target="_blank" href="{{$data->mail_1}}">
    <i class="fab fa-instagram" aria-hidden="true"></i>

</a>
@endif
@if (isset($data->mail ))

<a href="mailto:{{$data->mail}}">
                  <i class="fa fa-envelope" aria-hidden="true"></i>

</a>
@endif

                </div>
            </div>
            <div hidden class="col-md-3 footer-contact-info">
                <h5>{{__('index.contactInfo')}}</h5>
                <div class="footer-emails">

                    <p>{{ $data['email_1'] }}</p>
                    <p>{{ $data['email_2'] }}</p>



                </div>
                <div  class="footer-fax-tel">
                    <p>{{ $data['phone_1'] }}</p>
                    <p>{{ $data['phone_2'] }}</p>

                </div>
            </div>
            <div hidden class="col-md-2 footer-address">
                <h5>{{__('index.address')}}</h5>
                <p>
                <p>{{ $data['location_' . $lang] }}</p>

                </p>

            </div>
            <div class="col-md-3 rights d-flex justify-content-center ">
                <h5 class="le">All Rights Reserved © 2022 Hadq  </h5>
                <h5 class="le">Developed by <a href="https://sand.business/#Packages"><span class="sand">SAND</span></a>  </h5>
            </div>
        </div>
    </div>
    <div hidden class="second-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text">
                    <a href="#">{{__('index.group')}}</a>

                </div>
                <div class="col-md-6 logo">
                    <img src="https://i.ibb.co/B3MrbnX/Logo-03.png"  alt="logo">

                </div>
            </div>
        </div>
    </div>
</footer>
