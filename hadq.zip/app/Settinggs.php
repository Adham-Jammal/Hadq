<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Settinggs extends Model
{

}
